# Website de Portfólio - Wolfler Guzzo Ferreira

Este é o website de portfólio pessoal de Wolfler Guzzo Ferreira, desenvolvido para exibir experiência, projetos e habilidades em Python, Data Science e desenvolvimento web.

## 🌐 Website Online

**URL:** https://ussmxsjf.manus.space

## 📁 Estrutura do Projeto

```
wolflergf.com/
├── index.html              # Página inicial
├── about.html              # Página sobre
├── projects.html           # Página de projetos
├── blog.html              # Página do blog
├── contact.html           # Página de contato
├── assets/
│   ├── css/
│   │   └── style.css      # Estilos principais
│   ├── js/
│   │   └── script.js      # JavaScript interativo
│   └── images/
│       └── profile.png    # Imagem de perfil
├── downloads/
│   └── WolflerGuzzoFerreira_CV.pdf  # Currículo
└── README.md              # Esta documentação
```

## 🛠️ Tecnologias Utilizadas

- **HTML5** - Estrutura semântica
- **CSS3** - Estilização e layout responsivo
- **JavaScript (Vanilla)** - Interatividade
- **Formspree** - Formulário de contato
- **Google Fonts** - Tipografia (Montserrat + Open Sans)

## 🎨 Design

### Paleta de Cores
- **Primária:** `#2C3E50` (Azul Escuro/Marinho)
- **Secundária:** `#1ABC9C` (Ciano/Azul Claro)
- **Neutro Claro:** `#ECF0F1`
- **Neutro Escuro:** `#7F8C8D`
- **Destaque:** `#F39C12` (Laranja/Amarelo)

### Tipografia
- **Títulos:** Montserrat (Sans-serif)
- **Corpo:** Open Sans (Sans-serif)

## 📱 Responsividade

O website foi desenvolvido com abordagem mobile-first e é totalmente responsivo, funcionando perfeitamente em:
- Dispositivos móveis (smartphones)
- Tablets
- Desktops
- Telas grandes

## ✨ Funcionalidades

- **Navegação suave** entre seções
- **Menu mobile** responsivo
- **Formulário de contato** funcional
- **Animações CSS** sutis
- **Efeitos hover** interativos
- **Botão "voltar ao topo"**
- **SEO otimizado** com meta tags
- **Acessibilidade** com tags semânticas

## 📧 Formulário de Contato

O formulário de contato está integrado com Formspree e permite:
- Envio direto para o email
- Validação de campos
- Feedback visual para o usuário
- Diferentes categorias de assunto

## 🚀 Deploy

O website está hospedado e pode ser acessado em: **https://ussmxsjf.manus.space**

## 📄 Páginas

1. **Home** - Introdução e destaques
2. **Sobre** - História pessoal, formação e certificações
3. **Projetos** - Portfolio de projetos desenvolvidos
4. **Blog** - Artigos técnicos e experiências
5. **Contato** - Formulário e informações de contato

## 🔧 Como Executar Localmente

1. Clone ou baixe os arquivos do projeto
2. Navegue até a pasta do projeto
3. Execute um servidor HTTP local:
   ```bash
   python -m http.server 8000
   ```
4. Acesse `http://localhost:8000` no navegador

## 📞 Contato

- **Email:** wolfler@wolflergf.com
- **Website:** https://ussmxsjf.manus.space
- **LinkedIn:** [Conectar no LinkedIn]
- **GitHub:** [Ver projetos no GitHub]

---

**Desenvolvido por Wolfler Guzzo Ferreira** | 2025

